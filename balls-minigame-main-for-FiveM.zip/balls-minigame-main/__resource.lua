resource_manifest_version "44febabe-d386-4d18-afbe-5e627f4af937"

client_script "nui.lua"

ui_page "kulki-hack/index.html"
files {
    'kulki-hack/index.html',
    'kulki-hack/script.js',
    'kulki-hack/style.css',
    'kulki-hack/IBMPlexSans-Regular.ttf',
}
