local display = false

local time = 60  -- Czas w sekundach
local colorCount = 5 -- Liczba kolorów 
local tubeCount = 5 -- Liczba tub z kolorami
local ballsPerTube = 4 -- Liczba kul w jednej tubie
local emptyTubeCount = 2 -- Liczba pustych tub

RegisterCommand("kulki", function(source, args)
    SetDisplay(not display)
end)

RegisterNUICallback("exit", function(data)
    SetDisplay(false)
end)

RegisterNUICallback("resultWin", function(data)
    print("Win")
end)

RegisterNUICallback("resultLoss", function(data)
    print("Loss")
end)

Citizen.CreateThread(function()
    while display do
        Citizen.Wait(0)
        DisableControlAction(0, 1, display) 
        DisableControlAction(0, 2, display) 
        DisableControlAction(0, 142, display) 
        DisableControlAction(0, 18, display)
        DisableControlAction(0, 322, display)
        DisableControlAction(0, 106, display) 
    end
end)

function SetDisplay(bool)
    display = bool
    SetNuiFocus(bool, bool)
    SendNUIMessage({
        type = "ui",
        status = bool,
        time = time,
        colorCount = colorCount,
        tubeCount = tubeCount,
        ballsPerTube = ballsPerTube,
        emptyTubeCount = emptyTubeCount,
    })
end